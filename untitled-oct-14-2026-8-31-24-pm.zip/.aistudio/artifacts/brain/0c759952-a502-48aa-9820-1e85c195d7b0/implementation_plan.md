# Portal Legal y Política de Privacidad para Aplicaciones Móviles y Web

Un centro legal integral y portal de cumplimiento normativo diseñado para desarrolladores y empresas de aplicaciones móviles y web. Proporciona una Política de Privacidad rigurosa compatible con el RGPD europeo y las exigencias de Google Play Store y Apple App Store, junto con Términos de Servicio, Política de Cookies y un sistema interactivo de Solicitud de Eliminación de Datos de Usuario.

### User Review & Critical Decisions

> [!IMPORTANT]
> Decisiones confirmadas a partir de tus respuestas y parámetros de cumplimiento:

- **Enfoque del Portal**: Portal legal integral multisección con Política de Privacidad, Términos y Condiciones, Política de Cookies y Sistema de Eliminación de Datos.
- **Marco Normativo y Lenguaje**: En español con cumplimiento estricto de RGPD (Reglamento General de Protección de Datos de la UE) y las políticas obligatorias de seguridad de datos de Google Play y App Store.
- **Personalización para tu App**: Incluye un panel interactivo de configuración rápida donde puedes ingresar el nombre de tu app, empresa/desarrollador, email de contacto y tipo de datos recopilados (cámara, ubicación, analítica, publicidad), adaptando el texto legal al instante.
- **Herramientas de Exportación y Compartición**: Enlace directo público listo para pegar en Google Play Console / App Store Connect, copia de texto formateado en HTML/Markdown y generación de versión descargable/imprimible.

---

### 1. Overview & Core Concept

- **Qué hace la aplicación**: Ofrece una plataforma web pulida, profesional y de alta confianza que aloja los documentos legales obligatorios para cualquier aplicación móvil o web. Permite a los usuarios y revisores de tiendas de apps (Google Play / App Store) auditar fácilmente las prácticas de privacidad, y ofrece a los usuarios finales un canal funcional para ejercer sus derechos ARCO (Acceso, Rectificación, Cancelación y Oposición) y solicitar la eliminación de su cuenta o datos.
- **Público Objetivo**: Usuarios finales de la aplicación móvil, revisores de Google Play Store y App Store, y el desarrollador o equipo titular de la app.
- **Valor Principal**: Resuelve de forma definitiva el rechazo frecuente en tiendas de aplicaciones por URLs de privacidad inválidas o incompletas, cumpliendo con la exigencia de Google Play de proporcionar un mecanismo explícito de eliminación de datos en web.

---

### 2. User Experience & Visual Design

- **Flujos de Usuario Principales**:
  1. *Navegación de Documentos Legales*: Acceso instantáneo con pestañas limpias entre Política de Privacidad, Términos del Servicio, Política de Cookies y Formulario de Eliminación de Datos.
  2. *Tabla de Contenidos Interactiva y Búsqueda*: Menú lateral de navegación rápida que salta fluidamente a secciones clave (datos recopilados, permisos del dispositivo, proveedores terceros, derechos del usuario, retención).
  3. *Módulo de Eliminación de Datos (Data Deletion)*: Formulario formal donde el usuario introduce su correo de cuenta o ID de usuario, selecciona qué datos desea eliminar (cuenta completa, historial analítico, caché) y recibe confirmación con folio de solicitud.
  4. *Modo Personalización Rápida (Editor para el Desarrollador)*: Botón discreto "Configurar mi App" que permite cambiar en tiempo real el nombre de la app, correo de soporte, dirección legal y activar/desactivar módulos de terceros (AdMob, Firebase, Stripe, Google Analytics).
  5. *Acciones de Exportación*: Copiar enlace directo a la sección de privacidad, copiar texto en Markdown o imprimir/guardar como PDF.

- **Identidad Visual y Tema**:
  - *Estética*: Editorial institucional y tecnológica de alta fidelidad. Limpia, sobria, sin ruidos ni gradientes chillones. Inspirada en los estándares de cumplimiento de Stripe, GitHub y Vercel.
  - *Paleta de Colores*:
    - Lienzo: Blanco nítido y gris suave (`#F8FAFC` / `#FFFFFF`) con modo oscuro refinado (`#0F172A`).
    - Superficies estructurales: Bordes sutiles de 1px (`#E2E8F0` / `#1E293B`) y tarjetas con contraste suave.
    - Color de Acento: Azul institucional de confianza (`#1E40AF` / `#2563EB`) reservado exclusivamente para acciones primarias y navegación activa.
  - *Tipografía*:
    - Títulos y marca: `Plus Jakarta Sans` con tracking ajustado.
    - Texto legal y párrafos: `Public Sans` o `Inter` optimizada para lectura prolongada, altura de línea 1.65 y ancho máximo de lectura de 70ch.
    - Datos y folios: Monospace tabular (`font-mono tabular-nums`).
  - *Sin Píldoras Estáticas ni Clichés de IA*: Separadores tipográficos limpios (`·`), encabezados naturales numerados sin caracteres de código (`01. Información que recopilamos`), sin puntos verdes pulsantes decorativos ni puntuaciones ficticias.

---

### 3. Key Product Decisions & Trade-Offs

- **Estructura Modular del Contenido Legal**:
  - *Enfoque*: El texto legal se organiza mediante una estructura de datos TypeScript tipada y reactiva que inserta dinámicamente las variables de la app (nombre, desarrollador, tecnologías usadas, enlaces).
  - *Por qué*: Permite al usuario usar la web inmediatamente como su página pública de política de privacidad sin tocar código, mientras mantiene textos jurídicos redactados con precisión para auditorías de Google Play.
- **Gestión de la Solicitud de Eliminación de Datos**:
  - *Enfoque*: Formulario validado con almacenamiento local de solicitudes, generación de identificador de ticket, opción de envío directo por `mailto:` preformateado y descarga de comprobante en formato texto/JSON.
  - *Por qué*: Cumple de inmediato con las directrices de Google Play (que exigen una URL web pública donde los usuarios puedan solicitar la eliminación de su cuenta) sin necesidad obligatoria de backend complejo ni bases de datos de pago iniciales.
- **Acceso Directo por URL Hash / Rutas**:
  - *Enfoque*: Soporte para enlaces directos (`#privacidad`, `#terminos`, `#eliminacion-datos`) para que la URL compartida en la ficha de Google Play dirija exactamente a la vista requerida.

---

### 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────┐
│                       Top Navigation Bar                    │
│   [Nombre de la App / Legal]  ──  [Pestañas Legales]  ──  [Exportar / Compartir]   │
└─────────────────────────────────────────────────────────────┘
                               │
       ┌───────────────────────┴───────────────────────┐
       ▼                                               ▼
┌────────────────────────────┐   ┌──────────────────────────────────────────┐
│   Barra Lateral (Desktop)   │   │              Área de Lectura             │
│ ┌────────────────────────┐ │   │ ┌──────────────────────────────────────┐ │
│ │ • Resumen Ejecutivo    │ │   │ │ 01. Responsable del Tratamiento      │ │
│ │ • Datos que Recopilamos│ │   │ │ 02. Finalidades y Bases Jurídicas    │ │
│ │ • Permisos de la App   │ │   │ │ 03. Permisos de Dispositivo (Android)│ │
│ │ • Servicios Terceros   │ │   │ │ 04. Proveedores y Terceros           │ │
│ │ • Derechos RGPD (ARCO) │ │   │ │ 05. Seguridad y Retención            │ │
│ │ • Eliminación de Datos │ │   │ │ 06. Modificaciones y Contacto        │ │
│ └────────────────────────┘ │   │ └──────────────────────────────────────┘ │
│ [Botón Configurar Mi App]  │   │        [Botonera Copiar / Imprimir]      │
└────────────────────────────┘   └──────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│       Módulo Interactivo de Solicitud de Eliminación        │
│    (Formulario RGPD + Generación de Ticket + Mailto Directo)│
└─────────────────────────────────────────────────────────────┘
```

- **Modelo de Datos Principal**:
  - `AppLegalConfig`: Objeto con `appName`, `developerName`, `contactEmail`, `jurisdiction`, `lastUpdated`, `includedThirdParties` (Firebase Analytics, AdMob, Google Play In-App Billing, etc.), `permissions` (Ubicación, Cámara, Notificaciones, etc.).
  - `DeletionRequest`: ID de solicitud, correo del usuario, ID de cuenta, fecha, tipos de datos a suprimir, estado.
- **Componentes React**:
  - `TopBar`: Contrato de barra superior de 3 zonas según la constitución de diseño.
  - `DocumentViewer`: Renderizado tipográfico del documento seleccionado con índice dinámico y navegación por anclas.
  - `DeletionForm`: Interfaz formal para la solicitud de borrado exigida por Google Play.
  - `ConfigDrawer`: Modal/drawer discreto para que el desarrollador edite los datos de su app y vea la web actualizarse al instante.
  - `ShareExportModal`: Herramientas para copiar enlace directo de verificación para Play Store, copiar texto y descargar.
