# Rider Stats - Portal Legal y Política de Privacidad

Portal legal oficial, política de privacidad, términos de servicio y mecanismo web de eliminación de datos de usuario para **Rider Stats** (desarrollada por **SoloLegendsCorporation**).

Cumple estrictamente con las directrices de seguridad de datos de **Google Play Store** y el **RGPD (UE 2016/679)**.

---

## 🚀 Cómo Publicar Gratis en GitHub Pages

Este proyecto ya está configurado con rutas relativas (`base: './'`) en `vite.config.ts` y cuenta con un flujo automatizado de **GitHub Actions** (`.github/workflows/deploy.yml`).

### Paso 1: Crear un nuevo repositorio en GitHub
1. Inicia sesión en [GitHub](https://github.com/) y haz clic en **New repository** (Nuevo repositorio).
2. Nómbralo por ejemplo: `rider-stats-privacy` o `rider-stats-legal`.
3. Déjalo como **Public** (Público) para que la página sea visible y gratuita.
4. No inicialices con README (ya tenemos los archivos aquí).

### Paso 2: Subir el proyecto con Git
Abre tu terminal en la carpeta del proyecto y ejecuta:

```bash
# 1. Inicializar git (si no está inicializado)
git init

# 2. Agregar todos los archivos
git add .

# 3. Crear el primer commit
git commit -m "feat: portal legal y política de privacidad de Rider Stats"

# 4. Establecer la rama principal
git branch -M main

# 5. Vincular a tu repositorio remoto de GitHub (sustituye TU_USUARIO y TU_REPO)
git remote add origin https://github.com/TU_USUARIO/TU_REPO.git

# 6. Subir el código a GitHub
git push -u origin main
```

### Paso 3: Activar GitHub Pages en el repositorio
1. En tu repositorio en GitHub, entra a la pestaña **Settings** (Ajustes).
2. En la barra lateral izquierda, entra en **Pages**.
3. En la sección **Build and deployment**:
   - En **Source**, cambia de *"Deploy from a branch"* a **"GitHub Actions"**.
4. ¡Listo! El archivo `.github/workflows/deploy.yml` compilará y publicará la web automáticamente. En 1-2 minutos tu web estará activa.

---

## 🔗 URLs para Google Play Console

Una vez desplegado, tu web estará disponible en:
`https://TU_USUARIO.github.io/TU_REPO/`

Copia y pega estas direcciones en tu consola de Google Play:

- **Política de Privacidad de la App**:
  `https://TU_USUARIO.github.io/TU_REPO/#privacidad`

- **Mecanismo Web de Eliminación de Cuentas y Datos (Play Safety)**:
  `https://TU_USUARIO.github.io/TU_REPO/#eliminacion-datos`

- **Términos y Condiciones**:
  `https://TU_USUARIO.github.io/TU_REPO/#terminos`
