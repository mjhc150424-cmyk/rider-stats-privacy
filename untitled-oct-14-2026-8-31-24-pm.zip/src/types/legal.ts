export type DocumentType = 'privacy' | 'terms' | 'cookies' | 'deletion';

export interface DevicePermission {
  id: string;
  name: string;
  category: string;
  purpose: string;
  androidManifestKey: string;
  iosPlistKey: string;
  enabled: boolean;
}

export interface ThirdPartyService {
  id: string;
  name: string;
  category: 'analytics' | 'advertising' | 'auth_backend' | 'payments' | 'crash_reporting' | 'notifications';
  purpose: string;
  privacyPolicyUrl: string;
  dataShared: string;
  enabled: boolean;
}

export interface LegalSection {
  id: string;
  number: string;
  title: string;
  summary?: string;
  content: string[];
  subsections?: {
    subtitle: string;
    paragraphs: string[];
  }[];
  bullets?: string[];
  warningNote?: string;
}

export interface AppLegalConfig {
  appName: string;
  developerName: string;
  developerType: 'individual' | 'company';
  contactEmail: string;
  dpoEmail?: string;
  country?: string;
  city?: string;
  appPlatform: 'android' | 'ios' | 'both' | 'web';
  appStoreUrl?: string;
  playStoreUrl?: string;
  minimumAge: number;
  lastUpdated: string;
  version: string;
  hasInAppPurchases: boolean;
  hasUserAccounts: boolean;
  hasUserGeneratedContent: boolean;
  permissions: DevicePermission[];
  thirdParties: ThirdPartyService[];
}

export interface DeletionRequest {
  id: string;
  email: string;
  userAccountId?: string;
  scopes: ('account' | 'analytics' | 'activity_logs' | 'marketing')[];
  reason?: string;
  timestamp: string;
  status: 'pending' | 'processing' | 'completed';
}
