import React, { useState } from 'react';
import { AppLegalConfig, DocumentType, LegalSection } from '../types/legal';
import { X, Copy, Check, Printer, FileText, Code2, Link2, ExternalLink } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AppLegalConfig;
  activeDoc: DocumentType;
  sections: LegalSection[];
  docTitle: string;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  config,
  activeDoc,
  sections,
  docTitle,
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const baseUrl = window.location.origin + window.location.pathname;
  const privacyUrl = `${baseUrl}#privacidad`;
  const deletionUrl = `${baseUrl}#eliminacion-datos`;
  const termsUrl = `${baseUrl}#terminos`;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2200);
  };

  const generateMarkdown = () => {
    let md = `# ${docTitle} - ${config.appName}\n\n`;
    md += `> **Última actualización:** ${config.lastUpdated} | **Versión:** ${config.version}\n`;
    md += `> **Responsable:** ${config.developerName} (${config.contactEmail})\n\n`;

    sections.forEach((s) => {
      md += `## ${s.number}. ${s.title}\n\n`;
      if (s.summary) md += `*${s.summary}*\n\n`;
      s.content.forEach((p) => {
        md += `${p}\n\n`;
      });
      if (s.bullets && s.bullets.length > 0) {
        s.bullets.forEach((b) => {
          md += `- ${b}\n`;
        });
        md += '\n';
      }
      if (s.subsections && s.subsections.length > 0) {
        s.subsections.forEach((sub) => {
          md += `### ${sub.subtitle}\n\n`;
          sub.paragraphs.forEach((p) => {
            md += `${p}\n\n`;
          });
        });
      }
    });

    md += `---\nDocumento conforme a RGPD (UE 2016/679) y Directrices de Google Play.\n`;
    return md;
  };

  const generateHTML = () => {
    let html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${docTitle} - ${config.appName}</title></head><body>`;
    html += `<h1>${docTitle} - ${config.appName}</h1>`;
    html += `<p><em>Última actualización: ${config.lastUpdated} | Responsable: ${config.developerName}</em></p>`;
    sections.forEach((s) => {
      html += `<h2>${s.number}. ${s.title}</h2>`;
      if (s.summary) html += `<p><em>${s.summary}</em></p>`;
      s.content.forEach((p) => {
        html += `<p>${p}</p>`;
      });
      if (s.bullets && s.bullets.length > 0) {
        html += `<ul>${s.bullets.map((b) => `<li>${b}</li>`).join('')}</ul>`;
      }
    });
    html += `<hr><p>Documento regulado por RGPD y Google Play.</p></body></html>`;
    return html;
  };

  const handlePrint = () => {
    onClose();
    setTimeout(() => {
      window.print();
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity"
      />

      {/* Modal */}
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 z-10 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Compartir y Exportar para Tiendas de Apps
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              URLs y formatos listos para Google Play Console y App Store Connect.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-md hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs">
          {/* URLs section */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px] text-slate-400">
              Enlaces Directos Oficiales (Para Google Play / App Store)
            </h3>

            {/* Privacy URL */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-800">
                  URL de Política de Privacidad (Google Play / App Store)
                </span>
                <span className="text-[11px] text-emerald-700 font-medium">Requerido</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={privacyUrl}
                  className="w-full px-2.5 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-md text-slate-700 select-all"
                />
                <button
                  onClick={() => copyToClipboard(privacyUrl, 'privacy-url')}
                  className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-md transition-colors shrink-0"
                >
                  {copiedKey === 'privacy-url' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700">Copiado</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copiar</span>
                    </>
                  )}
                </button>
              </div>
              <p className="text-[11px] text-slate-500">
                Pega este enlace en: <em>Google Play Console &gt; Política &gt; Contenido de la app &gt; Política de Privacidad</em>.
              </p>
            </div>

            {/* Deletion URL */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-800">
                  URL de Eliminación de Cuenta de Usuario (Google Play Safety)
                </span>
                <span className="text-[11px] text-blue-700 font-medium">Play Store Requisito 2024+</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={deletionUrl}
                  className="w-full px-2.5 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-md text-slate-700 select-all"
                />
                <button
                  onClick={() => copyToClipboard(deletionUrl, 'deletion-url')}
                  className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-md transition-colors shrink-0"
                >
                  {copiedKey === 'deletion-url' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700">Copiado</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copiar</span>
                    </>
                  )}
                </button>
              </div>
              <p className="text-[11px] text-slate-500">
                Pega este enlace en: <em>Google Play Console &gt; Seguridad de los datos &gt; Eliminación de cuentas de usuario por web</em>.
              </p>
            </div>
          </div>

          {/* Document Export Options */}
          <div className="space-y-3 pt-4 border-t border-slate-100">
            <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px] text-slate-400">
              Exportar Contenido del Documento Activo
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                onClick={() => copyToClipboard(generateMarkdown(), 'markdown')}
                className="flex flex-col items-center justify-center p-3.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors text-center group"
              >
                <FileText className="w-5 h-5 text-slate-600 mb-1 group-hover:text-blue-600" />
                <span className="font-semibold text-slate-800">Copiar Markdown</span>
                <span className="text-[11px] text-slate-500 mt-0.5">
                  {copiedKey === 'markdown' ? '¡Copiado!' : 'Para GitHub o Docs'}
                </span>
              </button>

              <button
                onClick={() => copyToClipboard(generateHTML(), 'html')}
                className="flex flex-col items-center justify-center p-3.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors text-center group"
              >
                <Code2 className="w-5 h-5 text-slate-600 mb-1 group-hover:text-blue-600" />
                <span className="font-semibold text-slate-800">Copiar HTML</span>
                <span className="text-[11px] text-slate-500 mt-0.5">
                  {copiedKey === 'html' ? '¡Copiado!' : 'Para embeber en web'}
                </span>
              </button>

              <button
                onClick={handlePrint}
                className="flex flex-col items-center justify-center p-3.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors text-center group"
              >
                <Printer className="w-5 h-5 text-slate-600 mb-1 group-hover:text-blue-600" />
                <span className="font-semibold text-slate-800">Imprimir / PDF</span>
                <span className="text-[11px] text-slate-500 mt-0.5">Guardar como PDF</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-md transition-colors"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
