import React, { useState } from 'react';
import { LegalSection, AppLegalConfig, DocumentType } from '../types/legal';
import { Check, Copy, Shield, ExternalLink, AlertCircle } from 'lucide-react';

interface DocumentContentProps {
  documentType: DocumentType;
  title: string;
  leadDescription: string;
  sections: LegalSection[];
  config: AppLegalConfig;
  onNavigateToDeletion: () => void;
}

export const DocumentContent: React.FC<DocumentContentProps> = ({
  documentType,
  title,
  leadDescription,
  sections,
  config,
  onNavigateToDeletion,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopySectionLink = (id: string) => {
    const url = `${window.location.origin}${window.location.pathname}#${id}`;
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <article className="flex-1 min-w-0 bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-10 lg:p-12 shadow-xs print-container">
      {/* Header Area */}
      <header className="pb-8 mb-8 border-b border-slate-100">
        <div className="flex items-center gap-2 text-xs text-slate-500 mb-3">
          <span className="font-semibold text-slate-800">{config.appName}</span>
          <span aria-hidden="true">·</span>
          <span>Actualizado: {config.lastUpdated}</span>
          <span aria-hidden="true">·</span>
          <span>Versión {config.version}</span>
          <span aria-hidden="true">·</span>
          <span className="text-emerald-700 font-medium">{config.country || 'Honduras'}</span>
          <span aria-hidden="true">·</span>
          <span>Android</span>
        </div>

        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-slate-900 mb-4 text-balance">
          {title}
        </h1>

        <p className="text-base text-slate-600 leading-relaxed max-w-3xl">
          {leadDescription}
        </p>

        {/* Quick summary strip */}
        <div className="mt-6 pt-6 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div>
            <span className="text-slate-400 block mb-0.5">Responsable legal</span>
            <span className="font-medium text-slate-800">{config.developerName}</span>
          </div>
          <div>
            <span className="text-slate-400 block mb-0.5">Ubicación</span>
            <span className="font-medium text-slate-800">{config.country || 'Honduras'}</span>
          </div>
          <div>
            <span className="text-slate-400 block mb-0.5">Contacto oficial</span>
            <span className="font-medium text-slate-800 font-mono text-[11px] truncate block">{config.contactEmail}</span>
          </div>
          <div>
            <span className="text-slate-400 block mb-0.5">Estándar</span>
            <span className="font-medium text-slate-800">Google Play & RGPD</span>
          </div>
        </div>
      </header>

      {/* Main Sections */}
      <div className="space-y-12">
        {sections.map((section) => (
          <section
            key={section.id}
            id={section.id}
            className="scroll-mt-24 group relative"
          >
            {/* Section Header */}
            <div className="flex items-start justify-between gap-4 mb-3">
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2.5">
                <span className="text-sm font-mono font-medium text-blue-600 tabular-nums">
                  {section.number}.
                </span>
                <span>{section.title}</span>
              </h2>

              <button
                onClick={() => handleCopySectionLink(section.id)}
                className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md shrink-0 no-print"
                title="Copiar enlace a esta sección"
              >
                {copiedId === section.id ? (
                  <Check className="w-4 h-4 text-emerald-600" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </button>
            </div>

            {section.summary && (
              <p className="text-xs font-medium text-slate-500 mb-4 italic">
                {section.summary}
              </p>
            )}

            {/* Paragraphs */}
            <div className="space-y-3.5 text-sm sm:text-[15px] text-slate-700 leading-relaxed">
              {section.content.map((paragraph, idx) => (
                <p key={idx}>{paragraph}</p>
              ))}
            </div>

            {/* Subsections if present */}
            {section.subsections && section.subsections.length > 0 && (
              <div className="mt-6 space-y-5 pl-2 sm:pl-4 border-l border-slate-100">
                {section.subsections.map((sub, sIdx) => (
                  <div key={sIdx} className="space-y-2">
                    <h3 className="text-sm font-semibold text-slate-900">
                      {sub.subtitle}
                    </h3>
                    {sub.paragraphs.map((p, pIdx) => (
                      <p key={pIdx} className="text-sm text-slate-600 leading-relaxed">
                        {p}
                      </p>
                    ))}
                  </div>
                ))}
              </div>
            )}

            {/* Bullets if present */}
            {section.bullets && section.bullets.length > 0 && (
              <ul className="mt-4 space-y-2 text-sm text-slate-700">
                {section.bullets.map((bullet, bIdx) => (
                  <li key={bIdx} className="flex items-start gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0 mt-2" />
                    <span>{bullet}</span>
                  </li>
                ))}
              </ul>
            )}

            {/* Warning note if present */}
            {section.warningNote && (
              <div className="mt-4 p-3.5 bg-slate-50 border border-slate-200/80 rounded-lg text-xs text-slate-600 flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <span>{section.warningNote}</span>
              </div>
            )}

            {/* Special Interactive Section for Deletion if on privacy policy */}
            {section.id === 'derechos-arco' && (
              <div className="mt-5 p-4 bg-blue-50/60 border border-blue-200/60 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 no-print">
                <div>
                  <h4 className="text-sm font-semibold text-slate-900">
                    ¿Deseas solicitar la eliminación inmediata de tus datos o cuenta?
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Ponemos a tu disposición el canal directo requerido por las políticas de Google Play.
                  </p>
                </div>
                <button
                  onClick={onNavigateToDeletion}
                  className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  Solicitar Eliminación
                </button>
              </div>
            )}
          </section>
        ))}
      </div>

      {/* Document Footer Call to action */}
      <footer className="mt-14 pt-8 border-t border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-500">
        <div>
          <span>Documento legal verificado de </span>
          <strong className="text-slate-800">{config.appName}</strong>
          <span> · Válido para revisiones de Google Play Console & App Store Connect</span>
        </div>
        <div className="flex items-center gap-4">
          <a
            href={`mailto:${config.contactEmail}?subject=Consulta legal sobre ${config.appName}`}
            className="text-blue-600 hover:text-blue-800 font-medium inline-flex items-center gap-1"
          >
            <span>Contactar responsable</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </footer>
    </article>
  );
};
