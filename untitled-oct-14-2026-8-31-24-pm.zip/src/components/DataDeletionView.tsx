import React, { useState, useEffect } from 'react';
import { AppLegalConfig, DeletionRequest } from '../types/legal';
import { Trash2, Mail, Download, CheckCircle2, Clock, ShieldCheck, AlertTriangle } from 'lucide-react';

interface DataDeletionViewProps {
  config: AppLegalConfig;
}

const STORAGE_KEY = 'app_legal_deletion_requests';

export const DataDeletionView: React.FC<DataDeletionViewProps> = ({ config }) => {
  const [email, setEmail] = useState('');
  const [accountId, setAccountId] = useState('');
  const [scopes, setScopes] = useState<('account' | 'analytics' | 'activity_logs' | 'marketing')[]>([
    'account',
    'analytics',
  ]);
  const [reason, setReason] = useState('');
  const [acknowledged, setAcknowledged] = useState(false);
  const [submittedRequest, setSubmittedRequest] = useState<DeletionRequest | null>(null);
  const [pastRequests, setPastRequests] = useState<DeletionRequest[]>([]);
  const [formError, setFormError] = useState('');

  // Load existing requests from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setPastRequests(JSON.parse(stored));
      }
    } catch {
      // ignore storage errors
    }
  }, []);

  const handleToggleScope = (scope: 'account' | 'analytics' | 'activity_logs' | 'marketing') => {
    if (scopes.includes(scope)) {
      if (scopes.length === 1) return; // Keep at least one
      setScopes(scopes.filter((s) => s !== scope));
    } else {
      setScopes([...scopes, scope]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!email || !email.includes('@')) {
      setFormError('Por favor introduzca un correo electrónico válido asociado a su cuenta.');
      return;
    }
    if (!acknowledged) {
      setFormError('Debe marcar la casilla de confirmación para proceder con la solicitud.');
      return;
    }

    const newRequest: DeletionRequest = {
      id: `DEL-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 900 + 100)}`,
      email: email.trim(),
      userAccountId: accountId.trim() || undefined,
      scopes,
      reason: reason.trim() || undefined,
      timestamp: new Date().toISOString(),
      status: 'pending',
    };

    const updated = [newRequest, ...pastRequests];
    setPastRequests(updated);
    setSubmittedRequest(newRequest);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // storage quota fallback
    }

    // Reset fields
    setEmail('');
    setAccountId('');
    setReason('');
    setAcknowledged(false);
  };

  const handleDownloadReceipt = (req: DeletionRequest) => {
    const text = `COMPROBANTE DE SOLICITUD DE ELIMINACIÓN DE DATOS (RGPD / GOOGLE PLAY)
======================================================================
Aplicación: ${config.appName}
Responsable: ${config.developerName} (${config.contactEmail})
Folio / ID de Solicitud: ${req.id}
Fecha de Registro: ${new Date(req.timestamp).toLocaleString('es-ES')}
Correo Solicitante: ${req.email}
ID de Cuenta/Usuario: ${req.userAccountId || 'No especificado'}
Alcance de la supresión: ${req.scopes.join(', ')}
Motivo: ${req.reason || 'Sin motivo adicional indicado'}
Estado actual: Pendiente de tramitación (plazo legal máximo: 30 días naturales)

Instrucciones:
Conserve este identificador para cualquier seguimiento ante el responsable del tratamiento
o la Agencia de Protección de Datos.
======================================================================`;

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `comprobante-eliminacion-${req.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getMailtoLink = (req: DeletionRequest) => {
    const subject = encodeURIComponent(`Solicitud de Eliminación de Datos [${req.id}] - ${config.appName}`);
    const body = encodeURIComponent(
      `Estimado equipo de soporte de ${config.appName},\n\n` +
      `Por medio de la presente, solicito formalmente la eliminación y supresión definitiva de mi cuenta y datos personales con base en el Artículo 17 del RGPD y las directrices de Google Play.\n\n` +
      `Detalles de mi solicitud:\n` +
      `• Folio de Solicitud: ${req.id}\n` +
      `• Correo de la cuenta: ${req.email}\n` +
      `• ID / Alias de usuario: ${req.userAccountId || 'N/A'}\n` +
      `• Alcance solicitado: ${req.scopes.join(', ')}\n\n` +
      `Agradezco la confirmación por escrito una vez procesada la baja.\n\n` +
      `Atentamente,\n` +
      `${req.email}`
    );
    return `mailto:${config.contactEmail}?subject=${subject}&body=${body}`;
  };

  return (
    <article className="flex-1 min-w-0 bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-10 lg:p-12 shadow-xs">
      {/* Header */}
      <header className="pb-8 mb-8 border-b border-slate-100">
        <div className="flex items-center gap-2 text-xs text-slate-500 mb-3">
          <span>{config.appName}</span>
          <span aria-hidden="true">·</span>
          <span>Cumplimiento Google Play Store</span>
          <span aria-hidden="true">·</span>
          <span>Derecho de Supresión (Art. 17 RGPD)</span>
        </div>

        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-slate-900 mb-4 text-balance">
          Mecanismo y Solicitud de Eliminación de Datos de la Cuenta
        </h1>

        <p className="text-base text-slate-600 leading-relaxed max-w-3xl">
          En cumplimiento estricto de las directrices obligatorias de seguridad de datos de Google Play y del Reglamento General de Protección de Datos de la Unión Europea, esta página permite a cualquier usuario de <strong>{config.appName}</strong> solicitar el borrado completo de su cuenta y de los datos personales asociados.
        </p>
      </header>

      {/* Explanation Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-10">
        <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl space-y-1.5">
          <div className="flex items-center gap-2 text-slate-900 font-semibold text-xs">
            <Trash2 className="w-4 h-4 text-rose-600" />
            <span>Datos que se eliminarán</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Registros locales de turnos, kilometraje, estimaciones de ganancias y gastos de combustible en el dispositivo, así como la desvinculación de identificadores de publicidad.
          </p>
        </div>

        <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl space-y-1.5">
          <div className="flex items-center gap-2 text-slate-900 font-semibold text-xs">
            <Clock className="w-4 h-4 text-blue-600" />
            <span>Plazo de resolución</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Su solicitud será procesada en un plazo máximo de 30 días naturales. Recibirá notificación confirmando la eliminación.
          </p>
        </div>

        <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl space-y-1.5">
          <div className="flex items-center gap-2 text-slate-900 font-semibold text-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Retención legal bloqueada</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Solo se conservarán debidamente bloqueados aquellos datos exigidos por obligaciones fiscales o de prevención de fraude.
          </p>
        </div>
      </div>

      {/* Form Submission Confirmation Banner */}
      {submittedRequest && (
        <div className="mb-10 p-5 bg-emerald-50/80 border border-emerald-200 rounded-xl">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div className="flex-1 space-y-2">
              <h3 className="text-sm font-semibold text-emerald-950">
                ¡Solicitud Registrada con Éxito! (Folio: <span className="font-mono">{submittedRequest.id}</span>)
              </h3>
              <p className="text-xs text-emerald-800 leading-relaxed">
                Su petición ha quedado archivada. Para mayor celeridad y dejar constancia formal, le invitamos a enviar el mensaje preformateado a nuestro equipo o descargar su comprobante.
              </p>
              <div className="pt-2 flex flex-wrap gap-2.5">
                <a
                  href={getMailtoLink(submittedRequest)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-md transition-colors"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Enviar Confirmación por Email</span>
                </a>
                <button
                  onClick={() => handleDownloadReceipt(submittedRequest)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-800 bg-emerald-100/80 hover:bg-emerald-200/80 rounded-md transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Descargar Comprobante (.txt)</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Request Form */}
      <form onSubmit={handleSubmit} className="bg-slate-50/60 border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
        <div className="border-b border-slate-200/80 pb-3">
          <h2 className="text-base font-bold text-slate-900">
            Formulario Oficial de Solicitud de Supresión
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Complete los datos para que el responsable técnico localice sus registros en {config.appName}.
          </p>
        </div>

        {formError && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{formError}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Correo Electrónico de la Cuenta <span className="text-rose-500">*</span>
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="tu-correo@ejemplo.com"
              className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-hidden focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
            />
            <span className="text-[11px] text-slate-400 mt-1 block">
              El correo con el que te diste de alta o iniciaste sesión en la app.
            </span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nombre de Usuario o ID de Cuenta (Opcional)
            </label>
            <input
              type="text"
              value={accountId}
              onChange={(e) => setAccountId(e.target.value)}
              placeholder="Ej. usuario_123 o ID en el perfil"
              className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-hidden focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
            />
            <span className="text-[11px] text-slate-400 mt-1 block">
              Ayuda a ubicar tu cuenta de forma más rápida si es diferente a tu email.
            </span>
          </div>
        </div>

        {/* Scopes */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-2">
            Alcance de los datos a eliminar
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <label className="flex items-start gap-2.5 p-3 bg-white border border-slate-200 rounded-lg cursor-pointer hover:border-slate-300">
              <input
                type="checkbox"
                checked={scopes.includes('account')}
                onChange={() => handleToggleScope('account')}
                className="mt-0.5 rounded text-blue-600 focus:ring-blue-500"
              />
              <div>
                <span className="font-medium text-slate-800 block">Historial de turnos y métricas de delivery</span>
                <span className="text-slate-500 text-[11px]">Horas trabajadas, ganancias registradas y gastos de combustible.</span>
              </div>
            </label>

            <label className="flex items-start gap-2.5 p-3 bg-white border border-slate-200 rounded-lg cursor-pointer hover:border-slate-300">
              <input
                type="checkbox"
                checked={scopes.includes('analytics')}
                onChange={() => handleToggleScope('analytics')}
                className="mt-0.5 rounded text-blue-600 focus:ring-blue-500"
              />
              <div>
                <span className="font-medium text-slate-800 block">Identificadores de publicidad (Monetag / GAID)</span>
                <span className="text-slate-500 text-[11px]">Desvincular ID publicitario del dispositivo y registros de anuncios.</span>
              </div>
            </label>

            <label className="flex items-start gap-2.5 p-3 bg-white border border-slate-200 rounded-lg cursor-pointer hover:border-slate-300">
              <input
                type="checkbox"
                checked={scopes.includes('activity_logs')}
                onChange={() => handleToggleScope('activity_logs')}
                className="mt-0.5 rounded text-blue-600 focus:ring-blue-500"
              />
              <div>
                <span className="font-medium text-slate-800 block">Lecturas de kilometraje y odómetro</span>
                <span className="text-slate-500 text-[11px]">Borrador completo de distancias recorridas y cálculos de km.</span>
              </div>
            </label>

            <label className="flex items-start gap-2.5 p-3 bg-white border border-slate-200 rounded-lg cursor-pointer hover:border-slate-300">
              <input
                type="checkbox"
                checked={scopes.includes('marketing')}
                onChange={() => handleToggleScope('marketing')}
                className="mt-0.5 rounded text-blue-600 focus:ring-blue-500"
              />
              <div>
                <span className="font-medium text-slate-800 block">Token de notificaciones push</span>
                <span className="text-slate-500 text-[11px]">Baja definitiva de recordatorios y avisos de jornada.</span>
              </div>
            </label>
          </div>
        </div>

        {/* Reason */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Motivo de la solicitud (Opcional)
          </label>
          <textarea
            rows={2}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Coméntanos brevemente si hubo algún inconveniente con la app (opcional)..."
            className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-hidden focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
          />
        </div>

        {/* Acknowledgement */}
        <label className="flex items-start gap-2.5 text-xs text-slate-600 cursor-pointer">
          <input
            type="checkbox"
            checked={acknowledged}
            onChange={(e) => setAcknowledged(e.target.checked)}
            className="mt-0.5 rounded text-blue-600 focus:ring-blue-500"
          />
          <span>
            Entiendo que esta acción es irreversible y que, una vez tramitada, perderé acceso a mi cuenta, progresos y contenidos asociados en <strong>{config.appName}</strong>.
          </span>
        </label>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            className="px-5 py-2.5 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg shadow-xs transition-colors"
          >
            Registrar Solicitud de Eliminación
          </button>
        </div>
      </form>

      {/* History of Requests */}
      {pastRequests.length > 0 && (
        <section className="mt-12 pt-8 border-t border-slate-100">
          <h3 className="text-sm font-bold text-slate-900 mb-4">
            Historial de Solicitudes Registradas en este Navegador
          </h3>
          <div className="divide-y divide-slate-100 border border-slate-200/80 rounded-xl overflow-hidden bg-white text-xs">
            {pastRequests.map((req) => (
              <div key={req.id} className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono font-semibold text-slate-800">{req.id}</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-500">{new Date(req.timestamp).toLocaleDateString('es-ES')}</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-blue-700 font-medium">Registrada</span>
                  </div>
                  <div className="text-slate-600">
                    Cuenta: <span className="font-medium text-slate-800">{req.email}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <a
                    href={getMailtoLink(req)}
                    className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-slate-50 rounded-md transition-colors"
                    title="Reenviar email de confirmación"
                  >
                    <Mail className="w-4 h-4" />
                  </a>
                  <button
                    onClick={() => handleDownloadReceipt(req)}
                    className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-slate-50 rounded-md transition-colors"
                    title="Descargar comprobante"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </article>
  );
};
