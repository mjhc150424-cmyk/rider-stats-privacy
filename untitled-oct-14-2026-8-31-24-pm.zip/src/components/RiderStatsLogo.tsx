import React from 'react';

interface RiderStatsLogoProps {
  className?: string;
  size?: number;
}

export const RiderStatsLogo: React.FC<RiderStatsLogoProps> = ({
  className = 'w-9 h-9',
  size,
}) => {
  return (
    <svg
      viewBox="0 0 512 512"
      width={size}
      height={size}
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="Rider Stats Logo"
    >
      <defs>
        <linearGradient id="rsBg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0c121e" />
          <stop offset="100%" stopColor="#080d16" />
        </linearGradient>

        <linearGradient id="rsArc" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#059669" />
          <stop offset="35%" stopColor="#10b981" />
          <stop offset="100%" stopColor="#34d399" />
        </linearGradient>

        <linearGradient id="rsLine" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#d97706" />
          <stop offset="45%" stopColor="#f59e0b" />
          <stop offset="100%" stopColor="#fbbf24" />
        </linearGradient>
      </defs>

      {/* Squircle Background matching user icon */}
      <rect
        x="18"
        y="18"
        width="476"
        height="476"
        rx="118"
        fill="url(#rsBg)"
        stroke="#10b981"
        strokeWidth="8"
      />

      {/* Speedometer Arc */}
      <path
        d="M 132 355 A 155 155 0 1 1 385 168"
        stroke="url(#rsArc)"
        strokeWidth="26"
        strokeLinecap="round"
      />

      {/* Accent tick */}
      <path
        d="M 230 116 L 234 140"
        stroke="#0c121e"
        strokeWidth="6"
        strokeLinecap="round"
      />

      {/* Trend Arrow Line */}
      <polyline
        points="152,330 242,252 288,294 374,188"
        stroke="url(#rsLine)"
        strokeWidth="18"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Origin Node */}
      <circle cx="152" cy="330" r="12" fill="#10b981" />
      <circle cx="152" cy="330" r="5" fill="#a7f3d0" />

      {/* Midpoint Node */}
      <circle cx="242" cy="252" r="11" fill="#10b981" />
      <circle cx="242" cy="252" r="4.5" fill="#a7f3d0" />

      {/* Arrowhead */}
      <polygon
        points="368,158 408,194 360,207"
        fill="#fbbf24"
      />
    </svg>
  );
};
