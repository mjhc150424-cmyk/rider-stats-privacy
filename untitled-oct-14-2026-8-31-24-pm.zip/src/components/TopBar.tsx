import React from 'react';
import { DocumentType } from '../types/legal';
import { SlidersHorizontal, Share2 } from 'lucide-react';
import { RiderStatsLogo } from './RiderStatsLogo';

interface TopBarProps {
  appName: string;
  activeDoc: DocumentType;
  onSelectDoc: (doc: DocumentType) => void;
  onOpenConfig: () => void;
  onOpenExport: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  appName,
  activeDoc,
  onSelectDoc,
  onOpenConfig,
  onOpenExport,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href="#privacidad"
            onClick={(e) => {
              e.preventDefault();
              onSelectDoc('privacy');
            }}
            className="flex items-center gap-2.5 text-lg font-bold tracking-tight text-slate-900 hover:text-blue-700 transition-colors whitespace-nowrap shrink-0"
          >
            <RiderStatsLogo className="w-8 h-8 shrink-0 drop-shadow-xs" />
            <span>{appName}</span>
            <span className="text-slate-400 font-normal text-sm hidden sm:inline">Centro Legal</span>
          </a>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
          <button
            onClick={() => onSelectDoc('privacy')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              activeDoc === 'privacy'
                ? 'text-blue-600 font-semibold border-b-2 border-blue-600'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Política de Privacidad
          </button>
          <button
            onClick={() => onSelectDoc('terms')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              activeDoc === 'terms'
                ? 'text-blue-600 font-semibold border-b-2 border-blue-600'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Términos y Condiciones
          </button>
          <button
            onClick={() => onSelectDoc('cookies')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              activeDoc === 'cookies'
                ? 'text-blue-600 font-semibold border-b-2 border-blue-600'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Política de Cookies
          </button>
          <button
            onClick={() => onSelectDoc('deletion')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              activeDoc === 'deletion'
                ? 'text-blue-600 font-semibold border-b-2 border-blue-600'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Eliminación de Datos
          </button>
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={onOpenExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200/80 rounded-md transition-colors whitespace-nowrap shrink-0"
            title="Copiar URL para Google Play o exportar documento"
          >
            <Share2 className="w-3.5 h-3.5 text-slate-600" />
            <span className="hidden sm:inline">Compartir / Exportar</span>
          </button>
          <button
            onClick={onOpenConfig}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-md shadow-xs transition-colors whitespace-nowrap shrink-0"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Configurar App</span>
          </button>
        </div>
      </div>

      {/* Mobile Tab Strip */}
      <div className="md:hidden flex items-center overflow-x-auto px-4 py-2 border-t border-slate-100 bg-slate-50 gap-2 text-xs">
        <button
          onClick={() => onSelectDoc('privacy')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeDoc === 'privacy' ? 'bg-blue-600 text-white font-medium' : 'text-slate-600'
          }`}
        >
          Privacidad
        </button>
        <button
          onClick={() => onSelectDoc('terms')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeDoc === 'terms' ? 'bg-blue-600 text-white font-medium' : 'text-slate-600'
          }`}
        >
          Términos
        </button>
        <button
          onClick={() => onSelectDoc('cookies')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeDoc === 'cookies' ? 'bg-blue-600 text-white font-medium' : 'text-slate-600'
          }`}
        >
          Cookies
        </button>
        <button
          onClick={() => onSelectDoc('deletion')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeDoc === 'deletion' ? 'bg-blue-600 text-white font-medium' : 'text-slate-600'
          }`}
        >
          Eliminar Datos
        </button>
      </div>
    </header>
  );
};
