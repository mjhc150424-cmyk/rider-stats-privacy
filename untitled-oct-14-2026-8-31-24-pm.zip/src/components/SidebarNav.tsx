import React from 'react';
import { LegalSection } from '../types/legal';
import { Search, ChevronRight } from 'lucide-react';

interface SidebarNavProps {
  sections: LegalSection[];
  activeSectionId: string;
  onSelectSection: (id: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  documentTitle: string;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  sections,
  activeSectionId,
  onSelectSection,
  searchQuery,
  onSearchChange,
  documentTitle,
}) => {
  return (
    <aside className="w-full lg:w-72 shrink-0 self-start sticky top-24 space-y-5">
      {/* Search Input */}
      <div className="relative">
        <label htmlFor="search-sections" className="sr-only">Buscar en este documento</label>
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          id="search-sections"
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Buscar en el documento..."
          className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-hidden focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-colors"
        />
        {searchQuery && (
          <button
            onClick={() => onSearchChange('')}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
          >
            Limpiar
          </button>
        )}
      </div>

      {/* Table of contents */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs">
        <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-100">
          <span className="text-xs font-semibold text-slate-900 tracking-wide">
            Índice del Documento
          </span>
          <span className="text-xs text-slate-400 font-mono tabular-nums">
            {sections.length} secciones
          </span>
        </div>

        <nav className="space-y-1 max-h-[60vh] overflow-y-auto pr-1">
          {sections.length === 0 ? (
            <p className="text-xs text-slate-400 py-4 text-center">
              No hay secciones coincidentes con "{searchQuery}"
            </p>
          ) : (
            sections.map((sec) => {
              const isActive = activeSectionId === sec.id;
              return (
                <button
                  key={sec.id}
                  onClick={() => onSelectSection(sec.id)}
                  className={`w-full text-left px-2.5 py-2 rounded-lg text-xs transition-colors flex items-start gap-2.5 ${
                    isActive
                      ? 'bg-blue-50 text-blue-800 font-medium'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <span
                    className={`font-mono text-[11px] tabular-nums shrink-0 mt-0.5 ${
                      isActive ? 'text-blue-600 font-semibold' : 'text-slate-400'
                    }`}
                  >
                    {sec.number}
                  </span>
                  <span className="leading-snug flex-1 truncate">{sec.title}</span>
                  {isActive && (
                    <ChevronRight className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                  )}
                </button>
              );
            })
          )}
        </nav>
      </div>

      {/* Trust & Compliance Card */}
      <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-4 text-xs text-slate-600 space-y-2">
        <div className="font-semibold text-slate-900 text-xs">Cumplimiento Verificado</div>
        <div className="space-y-1 text-[11px] text-slate-500">
          <p>• RGPD UE 2016/679 (Directiva Europea)</p>
          <p>• Directrices de Seguridad de Google Play</p>
          <p>• Pautas de Privacidad de App Store Apple</p>
        </div>
      </div>
    </aside>
  );
};
