import React from 'react';
import { AppLegalConfig } from '../types/legal';
import { X, RotateCcw, Check, Sparkles } from 'lucide-react';

interface ConfigDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  config: AppLegalConfig;
  onChangeConfig: (newConfig: AppLegalConfig) => void;
  onResetDefaults: () => void;
}

export const ConfigDrawer: React.FC<ConfigDrawerProps> = ({
  isOpen,
  onClose,
  config,
  onChangeConfig,
  onResetDefaults,
}) => {
  if (!isOpen) return null;

  const handleTextChange = (field: keyof AppLegalConfig, value: any) => {
    onChangeConfig({
      ...config,
      [field]: value,
    });
  };

  const handleTogglePermission = (id: string) => {
    const updated = config.permissions.map((p) =>
      p.id === id ? { ...p, enabled: !p.enabled } : p
    );
    onChangeConfig({
      ...config,
      permissions: updated,
    });
  };

  const handleToggleThirdParty = (id: string) => {
    const updated = config.thirdParties.map((tp) =>
      tp.id === id ? { ...tp, enabled: !tp.enabled } : tp
    );
    onChangeConfig({
      ...config,
      thirdParties: updated,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity"
      />

      {/* Drawer Container */}
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col z-10 border-l border-slate-200">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Personalizar Datos de tu App
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Adapta los textos legales a tu aplicación en tiempo real.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-md hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {/* Basic App Details */}
          <section className="space-y-4">
            <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px] text-slate-400">
              Identidad de la Aplicación
            </h3>

            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Nombre de tu App
              </label>
              <input
                type="text"
                value={config.appName}
                onChange={(e) => handleTextChange('appName', e.target.value)}
                placeholder="Ej. MiAplicación"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:border-blue-600"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Nombre del Desarrollador / Empresa
              </label>
              <input
                type="text"
                value={config.developerName}
                onChange={(e) => handleTextChange('developerName', e.target.value)}
                placeholder="Ej. Tu Nombre o Estudio SL"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:border-blue-600"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Email de Contacto y Soporte
              </label>
              <input
                type="email"
                value={config.contactEmail}
                onChange={(e) => handleTextChange('contactEmail', e.target.value)}
                placeholder="contacto@tuapp.com"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:border-blue-600"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  País / Jurisdicción
                </label>
                <input
                  type="text"
                  value={config.country || ''}
                  onChange={(e) => handleTextChange('country', e.target.value)}
                  placeholder="Ej. Honduras"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:border-blue-600"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Versión
                </label>
                <input
                  type="text"
                  value={config.version}
                  onChange={(e) => handleTextChange('version', e.target.value)}
                  placeholder="Ej. 1.0.0"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:border-blue-600"
                />
              </div>
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Plataforma de Distribución
              </label>
              <select
                value={config.appPlatform}
                onChange={(e) => handleTextChange('appPlatform', e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:border-blue-600"
              >
                <option value="android">Android (Google Play)</option>
                <option value="ios">iOS (Apple App Store)</option>
                <option value="both">Ambas (Android e iOS)</option>
                <option value="web">Web App / PWA</option>
              </select>
            </div>
          </section>

          {/* Account & App Features */}
          <section className="space-y-3 pt-4 border-t border-slate-100">
            <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px] text-slate-400">
              Características de la App
            </h3>

            <label className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg cursor-pointer hover:bg-slate-100/70">
              <span className="font-medium text-slate-800">Tiene Cuentas de Usuario / Login</span>
              <input
                type="checkbox"
                checked={config.hasUserAccounts}
                onChange={(e) => handleTextChange('hasUserAccounts', e.target.checked)}
                className="rounded text-blue-600 focus:ring-blue-500"
              />
            </label>

            <label className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg cursor-pointer hover:bg-slate-100/70">
              <span className="font-medium text-slate-800">Compras integradas / Suscripciones</span>
              <input
                type="checkbox"
                checked={config.hasInAppPurchases}
                onChange={(e) => handleTextChange('hasInAppPurchases', e.target.checked)}
                className="rounded text-blue-600 focus:ring-blue-500"
              />
            </label>
          </section>

          {/* Device Permissions */}
          <section className="space-y-3 pt-4 border-t border-slate-100">
            <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px] text-slate-400">
              Permisos del Dispositivo Solicitados
            </h3>
            <p className="text-[11px] text-slate-500">
              Activa solo aquellos permisos que tu app declara en su AndroidManifest o Info.plist:
            </p>

            <div className="space-y-2">
              {config.permissions.map((perm) => (
                <label
                  key={perm.id}
                  className="flex items-start justify-between p-2.5 bg-slate-50 rounded-lg cursor-pointer hover:bg-slate-100/70"
                >
                  <div className="pr-2">
                    <span className="font-medium text-slate-800 block">{perm.name}</span>
                    <span className="text-[11px] text-slate-400 block font-mono">{perm.androidManifestKey}</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={perm.enabled}
                    onChange={() => handleTogglePermission(perm.id)}
                    className="mt-1 rounded text-blue-600 focus:ring-blue-500"
                  />
                </label>
              ))}
            </div>
          </section>

          {/* Third Party Services */}
          <section className="space-y-3 pt-4 border-t border-slate-100">
            <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px] text-slate-400">
              SDKs y Proveedores Terceros
            </h3>
            <p className="text-[11px] text-slate-500">
              Google Play audita rigurosamente que los SDKs presentes en el código estén declarados en la política:
            </p>

            <div className="space-y-2">
              {config.thirdParties.map((tp) => (
                <label
                  key={tp.id}
                  className="flex items-start justify-between p-2.5 bg-slate-50 rounded-lg cursor-pointer hover:bg-slate-100/70"
                >
                  <div className="pr-2">
                    <span className="font-medium text-slate-800 block">{tp.name}</span>
                    <span className="text-[11px] text-slate-500 block">{tp.purpose}</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={tp.enabled}
                    onChange={() => handleToggleThirdParty(tp.id)}
                    className="mt-1 rounded text-blue-600 focus:ring-blue-500"
                  />
                </label>
              ))}
            </div>
          </section>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-3">
          <button
            onClick={onResetDefaults}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 rounded-md transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restaurar Valores</span>
          </button>
          <button
            onClick={onClose}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-md shadow-xs transition-colors"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Guardar y Aplicar</span>
          </button>
        </div>
      </div>
    </div>
  );
};
