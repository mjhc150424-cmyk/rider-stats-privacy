import React, { useState, useEffect, useMemo } from 'react';
import { AppLegalConfig, DocumentType } from './types/legal';
import { DEFAULT_CONFIG } from './data/defaultConfig';
import {
  getPrivacyPolicySections,
  getTermsOfServiceSections,
  getCookiePolicySections,
} from './data/legalDocuments';
import { TopBar } from './components/TopBar';
import { SidebarNav } from './components/SidebarNav';
import { DocumentContent } from './components/DocumentContent';
import { DataDeletionView } from './components/DataDeletionView';
import { ConfigDrawer } from './components/ConfigDrawer';
import { ExportModal } from './components/ExportModal';
import { RiderStatsLogo } from './components/RiderStatsLogo';

const CONFIG_STORAGE_KEY = 'rider_stats_legal_config_v3';

export default function App() {
  // Load stored config or fallback to defaults
  const [config, setConfig] = useState<AppLegalConfig>(() => {
    try {
      const saved = localStorage.getItem(CONFIG_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return DEFAULT_CONFIG;
  });

  const [activeDoc, setActiveDoc] = useState<DocumentType>('privacy');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSectionId, setActiveSectionId] = useState('');
  const [isConfigOpen, setIsConfigOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);

  // Sync hash routing
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.toLowerCase().replace('#', '');
      if (hash === 'privacidad' || hash === 'privacy') {
        setActiveDoc('privacy');
      } else if (hash === 'terminos' || hash === 'terms') {
        setActiveDoc('terms');
      } else if (hash === 'cookies') {
        setActiveDoc('cookies');
      } else if (hash === 'eliminacion-datos' || hash === 'deletion' || hash === 'borrado') {
        setActiveDoc('deletion');
      } else if (hash) {
        // Maybe an anchor id
        const el = document.getElementById(hash);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
          setActiveSectionId(hash);
        }
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Update URL hash when document tab changes
  const handleSelectDoc = (doc: DocumentType) => {
    setActiveDoc(doc);
    setSearchQuery('');
    const hashMap: Record<DocumentType, string> = {
      privacy: 'privacidad',
      terms: 'terminos',
      cookies: 'cookies',
      deletion: 'eliminacion-datos',
    };
    window.history.replaceState(null, '', `#${hashMap[doc]}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Save config changes to localStorage
  const handleUpdateConfig = (newConfig: AppLegalConfig) => {
    setConfig(newConfig);
    try {
      localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(newConfig));
    } catch {
      // storage quota
    }
  };

  const handleResetDefaults = () => {
    setConfig(DEFAULT_CONFIG);
    try {
      localStorage.removeItem(CONFIG_STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  // Compute active document data
  const currentSections = useMemo(() => {
    if (activeDoc === 'privacy') return getPrivacyPolicySections(config);
    if (activeDoc === 'terms') return getTermsOfServiceSections(config);
    if (activeDoc === 'cookies') return getCookiePolicySections(config);
    return [];
  }, [activeDoc, config]);

  // Filter sections by search query
  const filteredSections = useMemo(() => {
    if (!searchQuery.trim()) return currentSections;
    const q = searchQuery.toLowerCase();
    return currentSections.filter(
      (sec) =>
        sec.title.toLowerCase().includes(q) ||
        sec.content.some((c) => c.toLowerCase().includes(q)) ||
        (sec.bullets && sec.bullets.some((b) => b.toLowerCase().includes(q))) ||
        (sec.summary && sec.summary.toLowerCase().includes(q))
    );
  }, [currentSections, searchQuery]);

  // Set default active section
  useEffect(() => {
    if (filteredSections.length > 0 && !activeSectionId) {
      setActiveSectionId(filteredSections[0].id);
    }
  }, [filteredSections, activeSectionId]);

  const handleScrollToSection = (id: string) => {
    setActiveSectionId(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const docTitleMap: Record<DocumentType, string> = {
    privacy: 'Política de Privacidad y Tratamiento de Datos',
    terms: 'Términos y Condiciones Generales de Uso',
    cookies: 'Política de Almacenamiento Local y Publicidad',
    deletion: 'Mecanismo Web de Eliminación y Supresión de Datos',
  };

  const docDescMap: Record<DocumentType, string> = {
    privacy: `Esta Política de Privacidad describe exhaustivamente cómo ${config.appName} gestiona los datos de los usuarios, con almacenamiento local en el dispositivo de turnos, kilometrajes y gastos de delivery, y despliegue de publicidad de Monetag, en estricto cumplimiento de las directrices de Google Play Store y el RGPD.`,
    terms: `Las presentes Condiciones de Uso rigen la utilización de ${config.appName} como herramienta independiente de gestión personal para repartidores y conductores de delivery.`,
    cookies: `Información detallada sobre el almacenamiento local en Android (SQLite y SharedPreferences) y tecnologías publicitarias de Monetag utilizadas en ${config.appName}.`,
    deletion: `Canal oficial exigido por Google Play Store para solicitar la supresión de datos, desvinculación telemétrica y borrado de registros.`,
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800">
      {/* Top Navigation */}
      <TopBar
        appName={config.appName}
        activeDoc={activeDoc}
        onSelectDoc={handleSelectDoc}
        onOpenConfig={() => setIsConfigOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
      />

      {/* Hero / Information Bar */}
      <div className="bg-white border-b border-slate-200/80 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <RiderStatsLogo className="w-12 h-12 shrink-0 drop-shadow-sm" />
            <div>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span className="font-semibold text-slate-900">{config.developerName}</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-700 font-medium">{config.country || 'Honduras'}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono">{config.contactEmail}</span>
                <span aria-hidden="true">·</span>
                <span>Android</span>
              </div>
              <h2 className="text-sm font-semibold text-slate-900 mt-0.5">
                Portal Oficial de Transparencia Legal y Privacidad
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto text-xs text-slate-500">
            <span>Validez: </span>
            <span className="font-medium text-slate-800">Google Play Store & RGPD</span>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 flex-1 w-full">
        <div className="flex flex-col lg:flex-row gap-8 items-start">
          {/* Sidebar Navigation (for legal documents) */}
          {activeDoc !== 'deletion' && (
            <div className="no-print w-full lg:w-72 shrink-0">
              <SidebarNav
                sections={filteredSections}
                activeSectionId={activeSectionId}
                onSelectSection={handleScrollToSection}
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
                documentTitle={docTitleMap[activeDoc]}
              />
            </div>
          )}

          {/* Document Content or Deletion View */}
          {activeDoc === 'deletion' ? (
            <DataDeletionView config={config} />
          ) : (
            <DocumentContent
              documentType={activeDoc}
              title={docTitleMap[activeDoc]}
              leadDescription={docDescMap[activeDoc]}
              sections={filteredSections}
              config={config}
              onNavigateToDeletion={() => handleSelectDoc('deletion')}
            />
          )}
        </div>
      </main>

      {/* Quiet Footer */}
      <footer className="bg-white border-t border-slate-200 mt-16 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            <span>© {new Date().getFullYear()} {config.developerName}. Todos los derechos reservados. </span>
            <span>Documentación legal para </span>
            <strong className="text-slate-700">{config.appName}</strong>.
          </div>

          <nav className="flex items-center gap-6">
            <button
              onClick={() => handleSelectDoc('privacy')}
              className="hover:text-slate-900 transition-colors"
            >
              Privacidad
            </button>
            <button
              onClick={() => handleSelectDoc('terms')}
              className="hover:text-slate-900 transition-colors"
            >
              Términos
            </button>
            <button
              onClick={() => handleSelectDoc('cookies')}
              className="hover:text-slate-900 transition-colors"
            >
              Cookies
            </button>
            <button
              onClick={() => handleSelectDoc('deletion')}
              className="hover:text-slate-900 transition-colors"
            >
              Eliminar Cuenta
            </button>
          </nav>
        </div>
      </footer>

      {/* Drawers and Modals */}
      <ConfigDrawer
        isOpen={isConfigOpen}
        onClose={() => setIsConfigOpen(false)}
        config={config}
        onChangeConfig={handleUpdateConfig}
        onResetDefaults={handleResetDefaults}
      />

      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        config={config}
        activeDoc={activeDoc}
        sections={currentSections}
        docTitle={docTitleMap[activeDoc]}
      />
    </div>
  );
}
