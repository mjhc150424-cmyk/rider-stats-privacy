import { AppLegalConfig, LegalSection } from '../types/legal';

export function getPrivacyPolicySections(config: AppLegalConfig): LegalSection[] {
  const activePermissions = config.permissions.filter((p) => p.enabled);
  const activeThirdParties = config.thirdParties.filter((tp) => tp.enabled);

  return [
    {
      id: 'responsable',
      number: '01',
      title: 'Identificación del Responsable del Tratamiento',
      summary: 'Entidad titular de la aplicación móvil y canales oficiales de atención.',
      content: [
        `La presente Política de Privacidad regula el tratamiento de información derivado de la descarga, instalación y uso de la aplicación móvil "${config.appName}".`,
        `• Titular y Desarrollador del Proyecto: ${config.developerName}`,
        `• Ubicación y Jurisdicción: ${config.country || 'Honduras'}`,
        `• Correo electrónico oficial de contacto y soporte: ${config.contactEmail}`,
        `• Canal de atención en materia de privacidad: Cualquier consulta, duda o ejercicio de derechos puede remitirse directamente a ${config.contactEmail}.`,
        `Este portal legal ha sido estructurado en estricto cumplimiento con los principios universales de protección de datos, el Reglamento General de Protección de Datos (RGPD) y las directrices obligatorias de seguridad de datos de Google Play Store.`,
      ],
    },
    {
      id: 'naturaleza-datos',
      number: '02',
      title: 'Naturaleza de la Aplicación y Datos Procesados',
      summary: 'Arquitectura de privacidad: almacenamiento local de turnos y métricas de delivery.',
      content: [
        `"${config.appName}" es una herramienta móvil diseñada para ayudar a repartidores, conductores y profesionales del delivery a gestionar de forma autónoma sus jornadas de trabajo, control de turnos, kilometraje, ganancias e ingresos por propinas, así como sus gastos operativos derivados (combustible, consumibles y mantenimiento del vehículo).`,
        `La arquitectura técnica de ${config.appName} prioriza la privacidad del usuario mediante los siguientes principios:`,
      ],
      subsections: [
        {
          subtitle: 'A. Almacenamiento Local de Datos Operativos y Financieros',
          paragraphs: [
            `Todos los registros introducidos por el usuario —incluyendo fechas y horas de turnos, tiempos trabajados, distancias recorridas en kilómetros o millas, lecturas de odómetro, ingresos brutos, propinas y gastos de combustible o reparaciones— se almacenan de manera local y privada en la memoria interna de su dispositivo (mediante SQLite / SharedPreferences).`,
            `Dichos datos operativos NO son transferidos, cargados, vendidos ni sincronizados en servidores externos de ${config.developerName}, ni se comparten con empresas o plataformas de intermediación de pedidos y delivery (tales como Uber Eats, Glovo, Rappi, DoorDash, Just Eat o similares). El repartidor mantiene la custodia total de su información.`,
          ],
        },
        {
          subtitle: 'B. Datos Técnicos y Publicitarios (Red de Monetización Monetag)',
          paragraphs: [
            `Para mantener la aplicación gratuita y accesible para los repartidores, ${config.appName} integra servicios de publicidad proporcionados por la red publicitaria Monetag.`,
            `Monetag puede recopilar de forma automatizada información no sensible de diagnóstico y publicidad: identificador de publicidad móvil de Google (Google Advertising ID - GAID), dirección IP aproximada para localización geográfica a nivel de región, tipo y modelo de dispositivo, versión del sistema operativo Android y métricas sobre la visualización o interacción con los anuncios publicitarios.`,
          ],
        },
        {
          subtitle: 'C. Notificaciones Push y Alertas de Conducción',
          paragraphs: [
            `Si el usuario concede el permiso de notificaciones, el sistema genera avisos locales y push en el dispositivo con el fin de recordar el inicio o finalización de turnos, el cumplimiento de metas diarias de facturación o el registro de kilometraje de la jornada.`,
          ],
        },
      ],
    },
    {
      id: 'bases-juridicas',
      number: '03',
      title: 'Bases Jurídicas del Tratamiento',
      summary: 'Fundamento legal aplicable para cada categoría de tratamiento.',
      content: [
        `El tratamiento de datos derivado de ${config.appName} se sustenta en las siguientes bases legales reconocidas:`,
        `1. Consentimiento expreso del usuario: Otorgado al aceptar los permisos específicos del dispositivo (como notificaciones push) o al consentir la visualización de publicidad personalizada conforme a las preferencias del sistema.`,
        `2. Interés legítimo y soporte funcional: El almacenamiento local de datos responde a la ejecución directa de la funcionalidad solicitada por el usuario (calcular resúmenes de ganancias y kilometraje), mientras que el despliegue de anuncios financia el desarrollo, mantenimiento y soporte continuo de la aplicación.`,
        `3. Cumplimiento normativo de Google Play: Mantener disponible este portal público con información verídica y el mecanismo web de solicitud de supresión de datos.`,
      ],
    },
    {
      id: 'permisos-android',
      number: '04',
      title: 'Permisos del Sistema Android Requeridos',
      summary: 'Desglose técnico de accesos al sistema y justificación de uso.',
      content: [
        `De conformidad con la directiva de seguridad de datos de Google Play, a continuación se detallan los permisos declarados en el archivo AndroidManifest de ${config.appName}:`,
      ],
      bullets: activePermissions.map(
        (p) => `${p.name} [${p.androidManifestKey}]: ${p.purpose}`
      ),
      warningNote:
        'Usted puede habilitar o inhabilitar cualquiera de estos permisos en cualquier instante accediendo en su dispositivo a: Ajustes > Aplicaciones > ' +
        config.appName +
        ' > Permisos.',
    },
    {
      id: 'proveedores-terceros',
      number: '05',
      title: 'Terceros Proveedores de Servicios Integrados',
      summary: 'Servicios de publicidad y plataforma que intervienen en la aplicación.',
      content: [
        `No vendemos sus datos personales bajo ninguna circunstancia. Para la operatividad técnica y monetización de la aplicación, interactúan los siguientes proveedores de servicios:`,
      ],
      bullets: activeThirdParties.map(
        (tp) =>
          `${tp.name} (${tp.category === 'advertising' ? 'Red Publicitaria' : 'Infraestructura de Plataforma'}): ${tp.purpose}. Datos procesados: ${tp.dataShared}. Política de privacidad: ${tp.privacyPolicyUrl}`
      ),
      subsections: [
        {
          subtitle: 'Gestión y Restablecimiento del Identificador Publicitario (GAID)',
          paragraphs: [
            `Usted puede restablecer o limitar en cualquier momento el identificador publicitario de Google utilizado por redes como Monetag desde su propio dispositivo Android, ingresando a: Ajustes de Google > Anuncios > "Restablecer ID de publicidad" o "Eliminar ID de publicidad".`,
          ],
        },
      ],
    },
    {
      id: 'seguridad-conservacion',
      number: '06',
      title: 'Conservación de Datos y Medidas de Seguridad',
      summary: 'Almacenamiento en el dispositivo y medidas de protección.',
      content: [
        `• Datos Operativos del Repartidor: Los registros de turnos, kilometrajes y gastos se almacenan únicamente en el almacenamiento aislado de la aplicación en el dispositivo del usuario mediante el sandbox de seguridad de Android. Permanecen allí hasta que el propio usuario decida borrarlos o desinstale la aplicación.`,
        `• Datos Publicitarios de Terceros: Los datos gestionados por Monetag o Google Play Services se conservan según los periodos de retención estipulados en sus respectivas políticas de privacidad para la prevención de fraude de clics e impresiones.`,
        `• Copias de Seguridad del Usuario: Si el usuario realiza una copia de seguridad de su dispositivo a través de Google Drive o servicios del fabricante, la base de datos local de la app puede incluirse en dicha copia según la configuración particular de su cuenta de Android.`,
      ],
    },
    {
      id: 'derechos-arco',
      number: '07',
      title: 'Derechos del Usuario y Supresión de Datos',
      summary: 'Mecanismos para eliminar datos locales y solicitudes de supresión.',
      content: [
        `Los usuarios de ${config.appName} disfrutan de plenos derechos de acceso, rectificación, supresión y limitación:`,
        `1. Eliminación Directa en el Dispositivo: Para borrar de forma inmediata e irrevocable todos sus turnos, ganancias y gastos registrados en la app, basta con acudir a: Ajustes de Android > Aplicaciones > ${config.appName} > Almacenamiento > "Borrar datos" o bien desinstalar la app.`,
        `2. Mecanismo Web de Supresión de Google Play: Para dar cumplimiento a la exigencia de Google Play Store sobre eliminación de cuentas y datos asociados por vía web, puede utilizar el formulario interactivo disponible en la pestaña "Eliminación de Datos" de este portal o enviar un correo a ${config.contactEmail}.`,
      ],
    },
    {
      id: 'menores',
      number: '08',
      title: 'Restricción de Edad y Protección de Menores',
      summary: 'Aplicación orientada a personas en edad laboral de conducción y delivery.',
      content: [
        `${config.appName} está orientada a personas mayores de ${config.minimumAge} años capacitadas legalmente para conducir vehículos o prestar servicios de entrega y reparto.`,
        `No recopilamos conscientemente datos de menores de dicha edad. En caso de detectarse cualquier registro accidental, se procederá a su eliminación inmediata tras notificación a ${config.contactEmail}.`,
      ],
    },
    {
      id: 'actualizaciones',
      number: '09',
      title: 'Modificaciones de la Política de Privacidad',
      summary: 'Notificación de revisiones periódicas o cambios normativos.',
      content: [
        `${config.developerName} se reserva el derecho de actualizar esta Política de Privacidad para adecuarla a nuevas funciones de la app, requerimientos de Google Play o regulaciones del sector.`,
        `Las modificaciones serán publicadas de forma permanente en esta dirección web, indicando la fecha de última revisión. Se aconseja a los usuarios consultar periódicamente esta página.`,
      ],
    },
  ];
}

export function getTermsOfServiceSections(config: AppLegalConfig): LegalSection[] {
  return [
    {
      id: 'terminos-naturaleza',
      number: '01',
      title: 'Aceptación y Objeto del Servicio',
      summary: 'Naturaleza de Rider Stats como herramienta de contabilidad y control personal.',
      content: [
        `Las presentes Condiciones Generales rigen el uso de la aplicación móvil "${config.appName}", desarrollada y distribuida por ${config.developerName}.`,
        `Al instalar o utilizar la app, el usuario acepta estos términos en su totalidad. ${config.appName} es una herramienta digital de cálculo, organización de turnos y registro personal de kilometraje y gastos para repartidores y conductores independientes.`,
      ],
    },
    {
      id: 'independencia-plataformas',
      number: '02',
      title: 'Deslinde de Responsabilidad e Independencia de Plataformas de Delivery',
      summary: 'Total desvinculación con empresas de delivery de terceros.',
      content: [
        `${config.appName} y ${config.developerName} son completamente independientes y NO tienen ninguna afiliación, relación societaria, asociación ni vínculo contractual con empresas de intermediación de delivery o transporte (incluyendo, a título enunciativo y no limitativo: Glovo, Uber Eats, Rappi, Deliveroo, DoorDash, Just Eat o similares).`,
        `Cualquier marca, logotipo o referencia a dichas plataformas se realiza exclusivamente con fines identificativos o descriptivos de la actividad del conductor. ${config.appName} no sustituye los sistemas oficiales de facturación, emisión de nóminas ni liquidaciones de las plataformas contratantes del usuario.`,
      ],
    },
    {
      id: 'seguridad-vial',
      number: '03',
      title: 'Seguridad Vial y Responsabilidad en la Conducción',
      summary: 'Uso responsable de la aplicación durante la circulación en vía pública.',
      content: [
        `El usuario es el único responsable de cumplir con las normas de tráfico y seguridad vial aplicables en su territorio de circulación.`,
        `Queda terminantemente prohibido manipular o interactuar con la aplicación mientras el vehículo (motocicleta, automóvil, bicicleta o patinete) se encuentre en movimiento. La configuración de turnos y registro de datos debe realizarse exclusivamente con el vehículo detenido de forma segura.`,
        `${config.developerName} no asume responsabilidad alguna por multas, infracciones de tránsito, accidentes viales o daños materiales ni corporales derivados de la conducción o de la distracción con dispositivos móviles.`,
      ],
    },
    {
      id: 'responsabilidad-fiscal',
      number: '04',
      title: 'Exactitud de los Datos y Obligaciones Fiscales',
      summary: 'Carácter orientativo de los cálculos de ganancias y gastos.',
      content: [
        `Los resúmenes de ganancias, promedios de kilometraje y balances de gastos generados por ${config.appName} tienen un propósito estrictamente estimativo y de organización personal.`,
        `El usuario es el único responsable de verificar la exactitud de sus registros contables, conservar sus comprobantes oficiales y cumplir con sus obligaciones tributarias, de seguridad social y fiscales correspondientes a su actividad económica.`,
      ],
    },
    {
      id: 'propiedad-licencia',
      number: '05',
      title: 'Propiedad Intelectual y Licencia Limitada',
      summary: 'Uso personal, intransferible y no exclusivo.',
      content: [
        `Todos los derechos sobre el código, diseño gráfico, logotipos, algoritmos de cálculo e interfaces de "${config.appName}" pertenecen exclusivamente a ${config.developerName}.`,
        `Se otorga una licencia de uso personal, no exclusiva y revocable para ejecutar la aplicación en dispositivos Android compatibles. Queda prohibida la descompilación, clonación o redistribución no autorizada.`,
      ],
    },
    {
      id: 'terminos-contacto',
      number: '06',
      title: 'Jurisdicción y Atención al Usuario',
      summary: 'Marco legal competente y canal directo de atención.',
      content: [
        `Las presentes condiciones se interpretan con arreglo al ordenamiento jurídico de ${config.country || 'Honduras'}, sin perjuicio de las normativas imperativas de protección de los derechos de usuarios y consumidores de servicios móviles en su territorio.`,
        `Para cualquier duda, aclaración o sugerencia sobre estas condiciones de uso, puede contactar al equipo de ${config.developerName} a través del correo: ${config.contactEmail}.`,
      ],
    },
  ];
}

export function getCookiePolicySections(config: AppLegalConfig): LegalSection[] {
  return [
    {
      id: 'cookies-almacenamiento-local',
      number: '01',
      title: 'Almacenamiento Local en Android (SQLite y SharedPreferences)',
      summary: 'Mecanismos de persistencia de datos en su dispositivo móvil.',
      content: [
        `"${config.appName}" es una aplicación móvil nativa para Android y no utiliza cookies de seguimiento tradicionales en su funcionamiento habitual en el dispositivo.`,
        `En su lugar, utiliza mecanismos de almacenamiento local seguro del sistema operativo Android:`,
        `• SharedPreferences: Para guardar configuraciones básicas (preferencias de notificaciones, metas de ingresos diarios, unidades de distancia en km o millas).`,
        `• Base de Datos SQLite Local: Para guardar de manera estructurada su historial de turnos de delivery, lecturas de odómetro, kilometraje recorrido, ingresos declarados y gastos de combustible. Estos datos permanecen confinados en el almacenamiento privado de la app en su teléfono.`,
      ],
    },
    {
      id: 'cookies-publicidad',
      number: '02',
      title: 'Tecnologías Publicitarias de Terceros (Monetag)',
      summary: 'Identificadores empleados por la red de monetización.',
      content: [
        `Los componentes publicitarios suministrados por Monetag pueden utilizar identificadores móviles temporales (como el GAID) y tecnologías de almacenamiento en memoria para:`,
        `1. Control de frecuencia (evitar mostrar el mismo anuncio de forma repetitiva al conductor).`,
        `2. Verificación de tráfico genuino y prevención de clics fraudulentos.`,
        `3. Entrega de formatos publicitarios adaptados a la resolución del dispositivo.`,
      ],
    },
    {
      id: 'cookies-limpieza',
      number: '03',
      title: 'Cómo Eliminar los Datos Almacenados en su Teléfono',
      summary: 'Instrucciones para vaciar el almacenamiento de Rider Stats.',
      content: [
        `Puede eliminar instantáneamente todos los datos y registros de turnos almacenados en cualquier momento siguiendo estos pasos en su teléfono Android:`,
        `1. Abra "Ajustes" o "Configuración" en su dispositivo.`,
        `2. Seleccione "Aplicaciones" y busque "${config.appName}".`,
        `3. Toque en "Almacenamiento y caché".`,
        `4. Pulse "Borrar almacenamiento" o "Borrar datos".`,
        `Esta acción vaciará por completo la base de datos local y restablecerá la app como si acabara de ser instalada.`,
      ],
    },
  ];
}
